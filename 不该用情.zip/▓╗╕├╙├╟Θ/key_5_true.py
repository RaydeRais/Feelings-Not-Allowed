import json
from LAC import LAC
from collections import defaultdict, Counter
from tqdm import tqdm

# 1. 读取数据
with open('主题聚类结果.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# 2. 初始化LAC
lac = LAC(mode='lac')

# 3. 统计每个聚类下高频名词
topic_texts = defaultdict(list)
for item in data:
    topic_num = item['topic_num']
    topic_texts[topic_num].append(item['content'])

topic_blacklist = dict()
for topic_num, texts in topic_texts.items():
    words = []
    for text in tqdm(texts, desc=f"主题{topic_num}分词中"):
        lac_result = lac.run(text)
        for word, tag in zip(lac_result[0], lac_result[1]):
            if tag.startswith('n') and len(word) >= 2:
                words.append(word)
    counter = Counter(words)
    # 高频名词作为黑名单，默认取前15个，也可人工微调
    topic_blacklist[topic_num] = set([w for w, c in counter.most_common(15)])
    print(f"主题{topic_num} 高频名词黑名单：{topic_blacklist[topic_num]}")

# 4. 再次遍历，分词后去除黑名单
results = []
for item in tqdm(data, desc="最终货品提取"):
    topic_num = item['topic_num']
    text = item['content']
    lac_result = lac.run(text)
    words, tags = lac_result[0], lac_result[1]
    # 剔除黑名单
    goods = [w for w, t in zip(words, tags) if t.startswith('n') and w not in topic_blacklist[topic_num] and len(w) >= 2]
    results.append({
        "index": item["index"],
        "topic_num": topic_num,
        "topic_keywords": item.get("topic_keywords"),
        "goods": goods,
        "content": text
    })

# 5. 保存新文件
with open('聚类货品自动提取结果.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)

print("完成！请打开 '聚类货品自动提取结果.json' 查看每条内容的货品抽取效果。")
