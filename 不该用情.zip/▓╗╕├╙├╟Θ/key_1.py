import json
import jieba
from collections import defaultdict, Counter

# 你自己的文件名
json_file = '主题聚类结果.json'

# 加载文件
with open(json_file, 'r', encoding='utf-8') as f:
    data = json.load(f)

# 构建字典，按 topic_num 分组
topic_contents = defaultdict(list)
for item in data:
    topic = item.get('topic_num')
    content = item.get('content', '')
    if topic is not None and content:
        topic_contents[topic].append(content)

# 设置一些常见的货品关键字，帮你筛选
goods_keywords = ['包', '鞋', '手机', '金条', '香水', '奢侈品', '酒', '奶粉', '衣服', '零食', '药', '手表', '配饰', '护肤品', '箱', '电子烟', 'iPhone', 'Coach', '爱马仕', '香奈儿']

# 统计每组的高频货品名称
result = {}

for topic, contents in topic_contents.items():
    words = []
    for text in contents:
        for word in jieba.lcut(text):
            # 只保留长度在2-6之间的中文词，避免“的”“是”等
            if 1 < len(word) <= 6 and any(kw in word for kw in goods_keywords):
                words.append(word)
    top_goods = Counter(words).most_common(15)
    result[topic] = top_goods

# 输出结果（可以直接保存为json）
import pprint
pprint.pprint(result)

# 也可以写出到json文件
with open('聚类货品统计结果.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
