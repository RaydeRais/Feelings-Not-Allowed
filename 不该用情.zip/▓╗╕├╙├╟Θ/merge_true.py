import pandas as pd

# 读表并整体去重（所有列内容完全一样才去重）
df1 = pd.read_csv(r'D:\不该用情\redbok\merged_1.csv').drop_duplicates()
df2 = pd.read_csv(r'D:\不该用情\redbok\merged_2.csv').drop_duplicates()

# 记录主键字段
key_cols = ['UID', '笔记链接']

# 找出除主键外，两个表重复的列名
dup_cols = [col for col in df1.columns if col in df2.columns and col not in key_cols]

# 只保留df2中不重复的列，避免合并后产生_x/_y
df2_unique = df2[[col for col in df2.columns if col not in dup_cols or col in key_cols]]

# 合并
df_merged = pd.merge(df1, df2_unique, how='left', on=key_cols)

# 导出
df_merged.to_csv(r'D:\不该用情\redbok\merged_left_join_dropdupcol.csv', index=False, encoding='utf-8-sig')
print('主表、副表都已去重，合并完成，没有重复列名！')
