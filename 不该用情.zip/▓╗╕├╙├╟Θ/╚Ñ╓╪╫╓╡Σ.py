import json

# 1. 读取你的黑名单文件
with open("global_goods_blacklist_cao.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# 2. 用 set 自动去重，再转回 list，按拼音排序方便人工查阅
# 替换第2步
data_unique = sorted(list(set(w.strip().lower() for w in data)))

# 3. 保存去重后的结果
with open("global_goods_blacklist.json", "w", encoding="utf-8") as f:
    json.dump(data_unique, f, ensure_ascii=False, indent=2)

print("去重后总数：", len(data_unique))
print("完成！结果已保存到 global_goods_blacklist.json")
