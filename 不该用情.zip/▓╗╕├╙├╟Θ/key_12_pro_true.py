import json
from LAC import LAC
from tqdm import tqdm

# 1. 读取聚类内容
with open('merged聚类结果clean.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# 2. 读取 topic 局部黑名单
with open('topic_keywords_blacklist_theme.json', 'r', encoding='utf-8') as f:
    topic_blacklist = json.load(f)
    topic_blacklist = {str(k): set(w.strip() for w in v) for k, v in topic_blacklist.items()}

# 3. 读取全局黑名单
with open('global_goods_blacklist.json', 'r', encoding='utf-8') as f:
    global_blacklist = set(w.strip() for w in json.load(f) if isinstance(w, str))

# 4. 初始化LAC
lac = LAC(mode='lac')

results = []
for item in tqdm(data, desc="自动提取货品"):
    topic_num = str(item['topic_num'])
    text = item['内容']
    lac_result = lac.run(text)
    words, tags = lac_result[0], lac_result[1]
    # 新增：过滤纯空白、去重
    raw_goods = [
        w.strip() for w, t in zip(words, tags)
        if t.startswith('n')
        and len(w.strip()) >= 2
        and w.strip() not in topic_blacklist.get(topic_num, set())
        and w.strip() not in global_blacklist
    ]
    # 进一步去重：只保留第一次出现
    goods = []
    seen = set()
    for w in raw_goods:
        if w and w not in seen:
            goods.append(w)
            seen.add(w)

    # 全字段保留，只加 goods
    new_item = item.copy()
    new_item['goods'] = goods
    results.append(new_item)

with open('merged聚类货品双重黑名单clean.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)

print("升级完成！剔除空格、自动去重。")
