import json
from LAC import LAC
from tqdm import tqdm

# 1. 读取聚类内容
with open('merged聚类结果.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# 2. 读取 topic 局部黑名单
with open('topic_keywords_blacklist_theme.json', 'r', encoding='utf-8') as f:
    topic_blacklist = json.load(f)
    # 统一key为str，所有词strip消除隐性空格
    topic_blacklist = {str(k): set(w.strip() for w in v) for k, v in topic_blacklist.items()}

# 3. 读取全局黑名单
with open('global_goods_blacklist.json', 'r', encoding='utf-8') as f:
    global_blacklist = set(w.strip() for w in json.load(f) if isinstance(w, str))

# 4. 初始化LAC
lac = LAC(mode='lac')

# 5. 自动提取（同时剔除topic和全局黑名单）
results = []
for item in tqdm(data, desc="自动提取货品"):
    topic_num = str(item['topic_num'])
    text = item['内容']
    lac_result = lac.run(text)
    words, tags = lac_result[0], lac_result[1]
    # 同时剔除topic黑名单和全局黑名单
    goods = [w for w, t in zip(words, tags)
             if t.startswith('n')
             and len(w) >= 2
             and w not in topic_blacklist.get(topic_num, set())
             and w not in global_blacklist]
    results.append({
        "index": item["index"],
        "topic_num": topic_num,
        "topic_keywords": item.get("topic_keywords"),
        "goods": goods,
        "内容": text
    })

with open('hg聚类货品双重黑名单.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)

print("完成！请打开 'hg聚类货品双重黑名单.json' 查看每条内容的货品抽取效果。")
