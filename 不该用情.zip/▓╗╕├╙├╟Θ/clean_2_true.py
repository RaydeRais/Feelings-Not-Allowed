import json

with open('merged_all.json', encoding='utf-8') as f:
    data = [json.loads(line) for line in f if line.strip()]

for item in data:
    for k in item:
        # 新的判断（带空字符串自动转为0）
        if "数" in k and isinstance(item[k], str) and (item[k].isdigit() or item[k] == ""):
            item[k] = int(item[k]) if item[k].isdigit() else 0

with open('merged_all_cleaned.json', 'w', encoding='utf-8') as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

print("清洗完成，所有'数'相关字段已转为数字，空字段自动设为0，已保存为 merged_all_cleaned.json")
