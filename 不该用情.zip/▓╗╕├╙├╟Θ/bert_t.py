from sentence_transformers import SentenceTransformer
sentence_model = SentenceTransformer("shibing624/text2vec-base-chinese")
from sentence_transformers import SentenceTransformer
from bertopic import BERTopic

# 1. 加载模型
sentence_model = SentenceTransformer("shibing624/text2vec-base-chinese")

# 2. 数据准备
import json
with open('hg_kouhuo.json', encoding='utf-8') as f:
    data = json.load(f)
docs = [item['content'] for item in data if 'content' in item and item['content']]

# 3. 生成文本向量
embeddings = sentence_model.encode(docs, show_progress_bar=True)

# 4. 主题建模
topic_model = BERTopic(language="chinese", embedding_model=sentence_model)
topics, probs = topic_model.fit_transform(docs, embeddings)

# 5. 查看主题
topic_model.get_topic_info()

import json

# 获取主题关键词的dict，topic_num => [keyword1, keyword2, ...]
topic_keywords = {}
for t in set(topics):
    kws = topic_model.get_topic(t)
    if kws is not None:
        topic_keywords[t] = [x[0] for x in kws]
    else:
        topic_keywords[t] = []

# 每条帖子组成大字典
all_result = []
for idx, (doc, topic, prob) in enumerate(zip(docs, topics, probs)):
    all_result.append({
        "index": idx + 1,
        "content": doc,
        "topic_num": int(topic),
        "topic_keywords": topic_keywords.get(topic, []),
        "topic_prob": float(prob) if prob is not None else None
    })

# 保存为json（记得 force_ascii=False 保留中文）
with open("hg聚类结果.json", "w", encoding="utf-8") as f:
    json.dump(all_result, f, ensure_ascii=False, indent=2)

print("全部聚类结果已保存为 hg聚类结果.json ！")

  