import os
import pandas as pd

folder = r'D:\不该用情\redbok\search'

# 自动获取所有csv文件名
file_names = [f for f in os.listdir(folder) if f.endswith('.csv')]

def read_csv_smart(f):
    path = os.path.join(folder, f)
    # 自动尝试 utf-8 和 gbk
    try:
        df = pd.read_csv(path, encoding='utf-8')
    except Exception:
        df = pd.read_csv(path, encoding='gbk')
    # 剔除多余的表头行（如果某行的第一个元素等于列名，说明是表头行）
    df = df[df[df.columns[0]] != df.columns[0]]
    return df

dfs = [read_csv_smart(f) for f in file_names]
df_all = pd.concat(dfs, ignore_index=True, sort=True)

# ====== 核心修改部分：根据“内容”和“UID”两列去重 ======
df_all = df_all.drop_duplicates(subset=["内容", "UID"])


# 导出
output_path = os.path.join(folder, 'merged_ray_final.csv')
df_all.to_csv(output_path, index=False, encoding='utf-8-sig')

print(f'合并完成，文件保存在: {output_path}')
