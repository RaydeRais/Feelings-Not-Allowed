from LAC import LAC
import json

lac = LAC(mode='lac')  # 'lac' 模式包含实体识别
results = []

with open('主题聚类结果.json', encoding='utf-8') as f:
    data = json.load(f)

for item in data:
    text = item['content']
    lac_result = lac.run(text)
    words, tags = lac_result[0], lac_result[1]
    # 只保留名词/实体（比如"拉布布"可能是n/商品名）
    goods = [w for w, t in zip(words, tags) if t.startswith('n') or t == 'PER' or t == 'ORG']
    print(f"index {item['index']}: {goods}")
    results.append({
    "index": item["index"],
    "topic_num": item.get("topic_num"),
    "topic_keywords": item.get("topic_keywords"),
    "goods": goods,
    "content": text
})


# 可选：保存结果到新文件
with open('聚类货品抽取结果.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)
