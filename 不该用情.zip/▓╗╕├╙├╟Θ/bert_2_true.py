import json
from sentence_transformers import SentenceTransformer
from bertopic import BERTopic
from tqdm import tqdm

# 1. 读取你的大json
with open('merged_all_cleaned.json', encoding='utf-8') as f:
    data = json.load(f)

# 2. 聚类内容（确保每条有'内容'字段）
docs = []
doc_indices = []
for idx, item in enumerate(data):
    text = item.get('内容', '')
    if text and isinstance(text, str) and len(text.strip()) > 5:
        docs.append(text.strip())
        doc_indices.append(idx)

print(f"有效聚类文本数量：{len(docs)}")

# 3. 加载BERT中文模型
sentence_model = SentenceTransformer("shibing624/text2vec-base-chinese")
embeddings = sentence_model.encode(docs, show_progress_bar=True)

# 4. BERTopic聚类
topic_model = BERTopic(language="chinese", embedding_model=sentence_model)
topics, probs = topic_model.fit_transform(docs, embeddings)

# 5. 主题关键词
topic_keywords = {}
for t in set(topics):
    kws = topic_model.get_topic(t)
    topic_keywords[t] = [x[0] for x in kws] if kws else []

# 6. 回填结果到原始结构
result = []
for i, (topic, prob) in enumerate(zip(topics, probs)):
    idx = doc_indices[i]
    item = data[idx].copy()  # 保留全部原始字段
    item['topic_num'] = int(topic)
    item['topic_keywords'] = topic_keywords.get(topic, [])
    item['topic_prob'] = float(prob) if prob is not None else None
    result.append(item)

# 7. 保存新文件
with open('merged聚类结果clean.json', 'w', encoding='utf-8') as f:
    json.dump(result, f, ensure_ascii=False, indent=2)
print('全部聚类结果已保存为 merged聚类结果clean.json ！')
