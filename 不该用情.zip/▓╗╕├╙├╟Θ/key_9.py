import json
from LAC import LAC
from tqdm import tqdm

# 1. 读取聚类内容
with open('hg聚类结果.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# 2. 读取全局黑名单
with open('global_goods_blacklist.json', 'r', encoding='utf-8') as f:
    global_blacklist = set(w.strip() for w in json.load(f) if isinstance(w, str))

# 3. 初始化LAC
lac = LAC(mode='lac')

results = []
for item in tqdm(data, desc="自动提取货品"):
    text = item['content']
    lac_result = lac.run(text)
    words, tags = lac_result[0], lac_result[1]
    # 只保留名词、2字以上、非黑名单
    goods = [w for w, t in zip(words, tags)
             if t.startswith('n') and len(w) >= 2 and w not in global_blacklist]
    results.append({
        "index": item.get("index"),
        "topic_num": item.get("topic_num"),
        "topic_keywords": item.get("topic_keywords"),
        "goods": goods,
        "content": text
    })

with open('hg_全局黑名单货品提取.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)

print("完成！请打开 'hg_全局黑名单货品提取.json' 查看货品抽取效果。")
