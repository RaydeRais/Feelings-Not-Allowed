import json
from LAC import LAC
from tqdm import tqdm

# 1. 读取聚类内容
with open('hg聚类结果.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# 2. 读取黑名单
with open('topic_keywords_blacklist.json', 'r', encoding='utf-8') as f:
    topic_blacklist = json.load(f)
    # 强制key为str
    topic_blacklist = {str(k): set(v) for k, v in topic_blacklist.items()}


lac = LAC(mode='lac')

# 3. 提取非黑名单名词为“货品”
results = []
for item in tqdm(data, desc="自动提取货品"):
    topic_num = str(item['topic_num'])  # 统一用str
    text = item['content']
    lac_result = lac.run(text)
    words, tags = lac_result[0], lac_result[1]
    goods = [w for w, t in zip(words, tags)
             if t.startswith('n') and len(w) >= 2 and w not in topic_blacklist.get(topic_num, set())]
    results.append({
        "index": item["index"],
        "topic_num": topic_num,
        "topic_keywords": item.get("topic_keywords"),
        "goods": goods,
        "content": text
    })

with open('hg聚类货品.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)
print("完成！请打开 'hg聚类货品.json' 查看每条内容的货品抽取效果。")
