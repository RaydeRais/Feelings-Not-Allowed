import json
from LAC import LAC
from tqdm import tqdm

# 1. 读取聚类内容
with open('hg聚类结果.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# 2. 读取黑名单
with open('topic_keywords_blacklist_1.json', 'r', encoding='utf-8') as f:
    # ① 原黑名单key转str，② 全部strip消除隐性空格
    raw_blacklist = json.load(f)
    topic_blacklist = {str(k): set(vv.strip() for vv in v) for k, v in raw_blacklist.items()}

# 3. （可选）生成全局黑名单，用于调试or全局过滤方案
all_blacklist = set()
for v in topic_blacklist.values():
    all_blacklist |= v

# 4. 初始化LAC
lac = LAC(mode='lac')

results = []
for item in tqdm(data, desc="自动提取货品"):
    topic_num = str(item['topic_num'])  # 保证类型一致
    text = item['content']
    lac_result = lac.run(text)
    words, tags = lac_result[0], lac_result[1]
    
    # 5. 黑名单过滤（按topic分组）
    topic_bl = topic_blacklist.get(topic_num, set())
    goods = []
    for w, t in zip(words, tags):
        # ① 剔除黑名单词条 ② 只保留2字及以上名词 ③ 额外strip清理
        w_strip = w.strip()
        if (
            t.startswith('n') and
            len(w_strip) >= 2 and
            w_strip not in topic_bl
        ):
            goods.append(w_strip)
    # （可选）如需全局过滤，将 topic_bl 换成 all_blacklist

    # 6. 调试输出：发现黑名单未覆盖的情况
    if not topic_bl:
        print(f"⚠️ 警告：topic_num={topic_num} 没有黑名单。原文片段：{text[:30]}")

    # 7. 结果存储
    results.append({
        "index": item["index"],
        "topic_num": topic_num,
        "topic_keywords": item.get("topic_keywords"),
        "goods": goods,
        "content": text
    })

# 8. 保存输出
with open('hg聚类货品_剔除黑名单.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)

print("完成！请打开 'hg聚类货品_剔除黑名单.json' 查看每条内容的货品抽取效果。")

# 【可选】如需调试全局黑名单剔除情况，将
#    topic_bl = topic_blacklist.get(topic_num, set())
#    换成
#    topic_bl = all_blacklist
