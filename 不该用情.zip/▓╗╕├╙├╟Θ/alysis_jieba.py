import pandas as pd
import jieba
from collections import Counter

df = pd.read_json('spy_Top50.json')
all_text = '。'.join(df['content'].dropna().tolist())
words = [w for w in jieba.lcut(all_text) if len(w) > 1]
stopwords = set(['的', '了', '和', '是', '都', '我', '也', '在', '被', '你', '这', '一个', '没有', '说', '就', '他们', '我们', '自己', '会', '海关', '扣货'])  # 可自定义
words = [w for w in words if w not in stopwords]
counter = Counter(words)
print(counter.most_common(30))
