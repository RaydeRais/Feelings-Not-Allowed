import json
from collections import defaultdict, Counter
from tqdm import tqdm
from datetime import datetime, timedelta
from sentence_transformers import SentenceTransformer
import numpy as np

# === 0. 加载你的聚类货品数据（已去黑名单） ===
with open('merged聚类货品双重黑名单clean.json', encoding='utf-8') as f:
    data = json.load(f)

# 1. 统计goods首次出现时间（新词检测）
goods_first_time = {}
for item in data:
    dt = None
    # 支持你的发布时间格式
    for k in ['发布时间', '发布', '时间']:
        if k in item:
            try:
                dt = datetime.strptime(item[k][:16], "%Y/%m/%d %H:%M")
                break
            except Exception:
                try:
                    dt = datetime.strptime(item[k][:10], "%Y/%m/%d")
                    break
                except Exception:
                    continue
    if not dt:
        continue  # 跳过没有时间的
    for w in set(item.get('goods', [])):
        if not w.strip(): continue
        if w not in goods_first_time or dt < goods_first_time[w]:
            goods_first_time[w] = dt

# 2. 统计goods出现在哪些聚类（多聚类覆盖）
goods_topic_map = defaultdict(set)
for item in data:
    tnum = item.get('topic_num')
    for w in set(item.get('goods', [])):
        if not w.strip(): continue
        goods_topic_map[w].add(tnum)

# 3. 统计goods出现总次数（可用于过滤极低频干扰词）
goods_counter = Counter()
for item in data:
    for w in item.get('goods', []):
        if w.strip():
            goods_counter[w] += 1

# 4. 新词榜单（近14天首次出现）
cutoff_date = max(goods_first_time.values()) - timedelta(days=14)
new_word_list = [
    {
        "goods": w,
        "first_seen": goods_first_time[w].strftime("%Y-%m-%d %H:%M"),
        "freq": goods_counter[w],
        "topic_count": len(goods_topic_map[w])
    }
    for w in goods_first_time
    if goods_first_time[w] >= cutoff_date and goods_counter[w] >= 1
]

# 5. 多聚类榜单（跨2个及以上主题的罕见词）
multi_topic_list = [
    {
        "goods": w,
        "topic_count": len(goods_topic_map[w]),
        "freq": goods_counter[w],
        "topics": list(goods_topic_map[w])
    }
    for w in goods_topic_map
    if len(goods_topic_map[w]) >= 2 and goods_counter[w] < 10  # 低频且跨主题，防止常见词刷榜
]

# 6. 语义离群榜单（每个topic内部，goods做embedding离群分析）
sentence_model = SentenceTransformer("shibing624/text2vec-base-chinese")
topic_goods = defaultdict(list)
topic_goods_examples = defaultdict(list)
for item in data:
    tnum = item.get('topic_num')
    goods = [w for w in item.get('goods', []) if w.strip()]
    if goods:
        topic_goods[tnum].extend(goods)
        topic_goods_examples[tnum].append({'goods': goods, 'text': item.get('内容')})

outlier_list = []
for tnum, goods_list in topic_goods.items():
    unique_goods = list(set(goods_list))
    if len(unique_goods) <= 2:
        continue
    # 只对有足够goods的主题聚类做离群分析
    embeddings = sentence_model.encode(unique_goods)
    center = np.mean(embeddings, axis=0, keepdims=True)
    dists = np.linalg.norm(embeddings - center, axis=1)
    # 离群度排名前4的goods入榜
    idx_top = np.argsort(dists)[-4:]
    for idx in idx_top:
        outlier_list.append({
            "goods": unique_goods[idx],
            "topic_num": tnum,
            "outlier_score": float(dists[idx]),
            "freq": goods_counter[unique_goods[idx]],
            "example": next(
                (eg['text'] for eg in topic_goods_examples[tnum] if unique_goods[idx] in eg['goods']), None)
        })

# 7. 综合榜单合并，打标签
final_candidates = {}

for x in new_word_list:
    w = x['goods']
    final_candidates.setdefault(w, {"goods": w, "tags": set()})
    final_candidates[w]['tags'].add('新词')
    final_candidates[w].update(x)

for x in multi_topic_list:
    w = x['goods']
    final_candidates.setdefault(w, {"goods": w, "tags": set()})
    final_candidates[w]['tags'].add('多聚类')
    final_candidates[w].update(x)

for x in outlier_list:
    w = x['goods']
    final_candidates.setdefault(w, {"goods": w, "tags": set()})
    final_candidates[w]['tags'].add('语义离群')
    final_candidates[w].update(x)

# 整理输出
output = []
for w, d in final_candidates.items():
    d['tags'] = list(d['tags'])
    output.append(d)
# 可以按标签数量和freq等综合排序
output = sorted(output, key=lambda x: (-len(x['tags']), x.get('freq', 0)), reverse=True)

with open('敏感goods三榜单合并版.json', 'w', encoding='utf-8') as f:
    json.dump(output, f, ensure_ascii=False, indent=2)

print("🎉 完成！请查收 '敏感goods三榜单合并版.json'，综合新词/多聚类/语义离群榜。")
