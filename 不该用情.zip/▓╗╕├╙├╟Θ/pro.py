import re
import time
import random
import pymongo
import pandas as pd
from datetime import datetime
from tqdm import tqdm
from scrapy.selector import Selector
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

# 数据清洗函数
def extract_number(List):
    """从字符串列表中提取第一个数字"""
    list_cleaned = []
    for x in List:
        if x is None or not isinstance(x, str):
            list_cleaned.append(None)
            continue
        number = re.findall(r'\d+\.?\d*', x)
        if number:
            list_cleaned.append(number[0])
        else:
            list_cleaned.append(None)
    return list_cleaned

def extract_large_number(List):
    """处理包含'万'的大数字并转换为整数"""
    list_cleaned = []
    for x in List:
        if x is None or not isinstance(x, str):
            list_cleaned.append(None)
            continue
        x = re.sub(r'[^\d.万]', '', x)  # 移除非数值字符
        if not x:
            list_cleaned.append(None)
            continue
        if '万' in x:
            number = float(x.replace('万', '')) * 10000
            list_cleaned.append(int(number))
        else:
            list_cleaned.append(int(float(x)))
    return list_cleaned

def extract_date(List):
    """从字符串列表中提取日期"""
    list_cleaned = []
    for x in List:
        if x is None or not isinstance(x, str):
            list_cleaned.append(None)
            continue
        match = re.search(r'(\d{4})-(\d{2})-(\d{2})', x)
        if match:
            date_cleaned = match.group(0)
        else:
            match = re.search(r'(\d{2})-(\d{2})', x)
            if match:
                current_year = datetime.now().year
                month, day = match.groups()
                date_cleaned = f'{current_year}-{month}-{day}'
            else:
                date_cleaned = None
        list_cleaned.append(date_cleaned)
    return list_cleaned

# 配置 Chrome 浏览器
service = Service("C:\\Program Files\\Google\\Chrome\\Application\\chromedriver.exe")  # 请替换为你的 chromedriver 路径
options = Options()
options.add_experimental_option('debuggerAddress', '127.0.0.1:9222')  # 调试模式
options.add_argument('--incognito')  # 无痕模式
browser = webdriver.Chrome(service=service, options=options)
action = ActionChains(browser)

# 登录状态检查和搜索
def selenium_test():
    global key_word, num
    browser.get('https://www.xiaohongshu.com/explore')
    # 检查登录状态
    while True:
        page_source = browser.page_source
        if '登录探索更多内容' in page_source:
            print('暂未登录，请手动登录')
            time.sleep(10)
        else:
            print('登录成功')
            break
    # 获取用户输入
    key_word = input("搜索关键词：")
    num = int(input("笔记爬取数量："))
    url = f'https://www.xiaohongshu.com/search_result?keyword={key_word}&source=web_explore_feed'
    browser.get(url)
    time.sleep(3)
    # 等待页面加载完成
    while key_word not in browser.title:
        time.sleep(2)

selenium_test()

# 更改模式和排序方式
def change_mode(browser):
    try:
        mode_button = browser.find_element(By.XPATH, '//*[@id="search-type"]/div/div/div[2]')
        mode_button.click()
        print('已自动更改模式为图文。')
    except Exception as e:
        print(f"更改模式失败: {e}")

def change_sort_order(browser, action):
    sort_order = {'综合': 1, '最新': 2, '最热': 3}
    print("请选择排序方式:\n1. 综合\n2. 最新\n3. 最热")
    selected_order_text = input("请输入排序方式对应的名称: ").strip()
    if selected_order_text not in sort_order:
        print("请输入有效的排序方式...")
        return
    selected_order_index = sort_order[selected_order_text]
    try:
        element = browser.find_element(By.XPATH, '//*[@id="global"]/div[2]/div[2]/div/div[1]/div[2]')
        action.move_to_element(element).perform()
        menu = browser.find_element(By.CLASS_NAME, 'dropdown-items')
        option = menu.find_element(By.XPATH, f'/html/body/div[4]/div/li[{selected_order_index}]')
        option.click()
        print('已选择排序方式为:', selected_order_text)
    except Exception as e:
        print(f"更改排序方式失败: {e}")

change_mode(browser)
change_sort_order(browser, action)

# 解析笔记列表
def parsePage(html_content, authorName_list, likeNr_list, URL_list, userURL_list, num):
    response = Selector(text=html_content)
    divs = response.xpath('//div[contains(@class, "feeds-container")]/section/div')
    for div in divs:
        if len(URL_list) >= num:
            break
        if div.xpath('.//span[contains(text(), "大家都在搜")]'):
            continue
        try:
            author_name = div.xpath('.//a[contains(@class, "author")]/span[contains(@class, "name")]/text()').get()
            like_nr = div.xpath('.//span[contains(@class, "count")]/text()').get()
            url = div.xpath('.//a[contains(@class, "cover")]/@href').get()
            user_url = div.xpath('.//a[contains(@class, "author")]/@href').get()
            if author_name and like_nr and url and user_url:
                authorName_list.append(author_name)
                likeNr_list.append(like_nr)
                URL_list.append(url)
                userURL_list.append(user_url)
            else:
                print(f"跳过一条数据，因缺少必要字段: author_name={author_name}, like_nr={like_nr}, url={url}, user_url={user_url}")
            time.sleep(0.35)
        except Exception as e:
            print(f"解析笔记时出错: {e}")
    return True

authorName_list, likeNr_list, URL_list, userURL_list = [], [], [], []
qbar = tqdm(total=num, desc="已获取的笔记数量...")
while len(URL_list) < num:
    if '- THE END -' in browser.page_source:
        print(f"当前与{key_word}有关的笔记数量少于 {num}")
        break
    parsePage(browser.page_source, authorName_list, likeNr_list, URL_list, userURL_list, num)
    qbar.update(1)
    if len(URL_list) < num:
        browser.execute_script('window.scrollTo(0,document.body.scrollHeight)')
        time.sleep(random.uniform(3, 5))
if len(URL_list) > num:
    authorName_list = authorName_list[:num]
    likeNr_list = likeNr_list[:num]
    URL_list = URL_list[:num]
    userURL_list = userURL_list[:num]
qbar.close()

# 清洗列表数据
likeNr_list = extract_large_number(likeNr_list)
URL_list = [re.sub(r'^/search_result/', '/', url) for url in URL_list if url is not None]
userURL_list = [url.split('/')[-1] for url in userURL_list if url is not None]

# 解析笔记详情页面
def parse_note_page(browser, url, commentNr_list, content_list, datePublished_list, images_list, starNr_list):
    whole_url = 'https://www.xiaohongshu.com/explore' + url
    browser.get(whole_url)
    try:
        WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@name="description"]')))
    except Exception as e:
        print(f"页面加载超时 for URL: {whole_url}, 错误: {e}")
    html = browser.page_source
    selector = Selector(text=html)
    
    # 提取字段，若失败则返回 None
    comment_nr = selector.xpath('//*[@class="total"]/text()').extract_first(default=None)
    content = selector.xpath('//*[@name="description"]/@content').extract_first(default=None)
    datePublished = selector.xpath('//*[@class="date"]/text()').extract_first(default=None)
    images = selector.xpath('//*[@name="og:image"]/@content').extract_first(default=None)
    images = images + '.jpg' if images else None
    star_nr = selector.xpath('//*[@class="count"]/text()').extract_first(default=None)
    
    # 添加到列表
    commentNr_list.append(comment_nr)
    content_list.append(content)
    datePublished_list.append(datePublished)
    images_list.append(images)
    starNr_list.append(star_nr)
    
    # 记录提取失败的字段
    if comment_nr is None:
        print(f"评论数量提取失败 for URL: {whole_url}")
    if datePublished is None:
        print(f"发布时间提取失败 for URL: {whole_url}")

commentNr_list, content_list, datePublished_list, images_list, starNr_list = [], [], [], [], []
qbar = tqdm(total=len(URL_list), desc="已获取的笔记详情数量...")
for url in URL_list:
    parse_note_page(browser, url, commentNr_list, content_list, datePublished_list, images_list, starNr_list)
    qbar.update(1)
    time.sleep(random.uniform(0.5, 2))
qbar.close()

# 清洗详情数据
commentNr_list = extract_large_number(extract_number(commentNr_list))
starNr_list = extract_large_number(starNr_list)
datePublished_list = extract_date(datePublished_list)

# 整合数据为 DataFrame
dic = {
    "author_name": authorName_list,
    "like_nr": likeNr_list,
    "url": URL_list,
    "user_url": userURL_list,
    "comment_nr": commentNr_list,
    "content": content_list,
    "datePublished": datePublished_list,
    "images": images_list,
    "star_nr": starNr_list,
}
df = pd.DataFrame.from_dict(dic)
df = df[~df.duplicated(keep='first')]
print(f"删除 {num - len(df)} 行重复行后剩余 {len(df)} 行。")

# 保存到 MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017/")  # MongoDB 连接地址
db = client["xiaohongshu"]  # 数据库名
collection = db["notes"]    # 集合名
collection.insert_many(df.to_dict('records'))  # 将数据插入 MongoDB
print("数据已成功保存到 MongoDB。")
client.close()  # 关闭连接