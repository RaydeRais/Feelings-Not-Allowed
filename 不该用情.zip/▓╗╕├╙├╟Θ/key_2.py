import json
from LAC import LAC
from collections import defaultdict, Counter
from tqdm import tqdm

# 1. 读取数据
with open('主题聚类结果.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# 2. 初始化LAC
lac = LAC(mode='lac')  # 'lac'模式下名词分得细，'seg'为粗分词

# 3. 分组统计
topic_texts = defaultdict(list)
for item in data:
    topic_num = item['topic_num']
    content = item['content']
    topic_texts[topic_num].append(content)

# 4. 对每个主题分组，分词统计高频名词
for topic_num, texts in topic_texts.items():
    print(f'\n=== 主题 {topic_num} ===')
    words = []
    for text in tqdm(texts, desc=f"主题{topic_num}分词中"):
        lac_result = lac.run(text)
        for word, tag in zip(lac_result[0], lac_result[1]):
            if tag.startswith('n') and len(word) >= 2:  # 只保留名词（n*），2字及以上
                words.append(word)
    # 统计高频
    counter = Counter(words)
    print(f"高频名词（TOP30）：")
    for w, c in counter.most_common(30):
        print(f"{w}: {c}")
