import re
import time
import random
import pymongo
import pandas as pd
from datetime import datetime
from tqdm import tqdm
from scrapy.selector import Selector

from webdriver_manager.chrome import ChromeDriverManager
import shutil
import os

# === 自动同步新版 chromedriver.exe 到指定目录 ===
chromedriver_path = ChromeDriverManager().install()
target_path = r"C:\Program Files\Google\Chrome\Application\chromedriver.exe"
if not os.path.exists(target_path) or os.path.getmtime(chromedriver_path) > os.path.getmtime(target_path):
    try:
        shutil.copyfile(chromedriver_path, target_path)
        print(f"已自动同步新版 chromedriver 到 {target_path}")
    except PermissionError:
        print(f"没有权限写入 {target_path}，请用管理员身份运行 python！")
        exit(1)

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

# === 数据清洗函数 ===
def extract_number(List):
    list_cleaned = []
    for x in List:
        if x is None or not isinstance(x, str):
            list_cleaned.append(None)
            continue
        number = re.findall(r'\d+\.?\d*', x)
        if number:
            list_cleaned.append(number[0])
        else:
            list_cleaned.append(None)
    return list_cleaned

def extract_large_number(List):
    list_cleaned = []
    for x in List:
        if x is None or not isinstance(x, str):
            list_cleaned.append(None)
            continue
        x = re.sub(r'[^\d.万]', '', x)
        if not x:
            list_cleaned.append(None)
            continue
        if '万' in x:
            number = float(x.replace('万', '')) * 10000
            list_cleaned.append(int(number))
        else:
            list_cleaned.append(int(float(x)))
    return list_cleaned

def extract_date(List):
    list_cleaned = []
    for x in List:
        if x is None or not isinstance(x, str):
            list_cleaned.append(None)
            continue
        match = re.search(r'(\d{4})-(\d{2})-(\d{2})', x)
        if match:
            date_cleaned = match.group(0)
        else:
            match = re.search(r'(\d{2})-(\d{2})', x)
            if match:
                current_year = datetime.now().year
                month, day = match.groups()
                date_cleaned = f'{current_year}-{month}-{day}'
            else:
                date_cleaned = None
        list_cleaned.append(date_cleaned)
    return list_cleaned

# === 配置 Chrome 浏览器 ===
service = Service(r"C:\Program Files\Google\Chrome\Application\chromedriver.exe")
options = Options()
options.add_experimental_option('debuggerAddress', '127.0.0.1:9222')
options.add_argument('--incognito')
browser = webdriver.Chrome(service=service, options=options)
action = ActionChains(browser)

# === 登录状态检查和搜索 ===
def selenium_test():
    global key_word, num
    browser.get('https://www.xiaohongshu.com/explore')
    while True:
        page_source = browser.page_source
        if '登录探索更多内容' in page_source:
            print('暂未登录，请手动登录')
            time.sleep(10)
        else:
            print('登录成功')
            break
    key_word = input("搜索关键词：")
    try:
        num = int(input("笔记爬取数量："))
    except ValueError:
        print("请输入有效的整数作为爬取数量。")
        return
    url = f'https://www.xiaohongshu.com/search_result?keyword={key_word}&source=web_explore_feed'
    browser.get(url)
    time.sleep(3)
    while key_word not in browser.title:
        time.sleep(2)

selenium_test()

# === 更改模式和排序方式 ===
def change_mode(browser):
    try:
        WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="search-type"]/div/div/div[2]'))
        )
        mode_button = browser.find_element(By.XPATH, '//*[@id="search-type"]/div/div/div[2]')
        mode_button.click()
        print('已自动更改模式为图文。')
    except Exception as e:
        print(f"更改模式失败: {e}")

def change_sort_order(browser):
    global selected_order_text
    action = ActionChains(browser)
    sort_order = {'综合': 1, '最新': 2, '最热': 3}
    print("请选择排序方式:\n1. 综合\n2. 最新\n3. 最热")
    selected_order_text = input("请输入排序方式对应的名称: ").strip()
    if selected_order_text not in sort_order:
        print("请输入有效的排序方式...")
        return selected_order_text
    try:
        WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="global"]/div[2]/div[2]/div/div[1]/div[2]'))
        )
        element = browser.find_element(By.XPATH, '//*[@id="global"]/div[2]/div[2]/div/div[1]/div[2]')
        action.move_to_element(element).perform()
        WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, 'dropdown-items'))
        )
        menu = browser.find_element(By.CLASS_NAME, 'dropdown-items')
        selected_order_index = sort_order[selected_order_text]
        option_xpath = f'.//li[{selected_order_index}]'
        WebDriverWait(browser, 10).until(
            EC.element_to_be_clickable((By.XPATH, option_xpath))
        )
        option = menu.find_element(By.XPATH, option_xpath)
        try:
            option.click()
        except:
            browser.execute_script("arguments[0].click();", option)
        print('已选择排序方式为:', selected_order_text)
    except Exception as e:
        print(f"更改排序方式失败: {e}")
    return selected_order_text

change_mode(browser)
selected_order_text = change_sort_order(browser)

# === 解析笔记列表 ===
def is_valid_like(like):
    # 允许数字、带“万”，过滤“赞”和空
    if not like or like == '赞':
        return False
    # 允许 123、12.5、3万、2.1万
    return bool(re.match(r'^\d+(\.\d+)?(万)?$', like))

def parsePage(html_content, authorName_list, likeNr_list, URL_list, userURL_list, num):
    response = Selector(text=html_content)
    divs = response.xpath('//div[contains(@class, "feeds-container")]/section/div')
    for div in divs:
        if len(URL_list) >= num:
            break
        # 过滤“大家都在搜”等聚合卡片
        if div.xpath('.//span[contains(text(), "大家都在搜")]'):
            continue
        try:
            author_name = div.xpath('.//a[contains(@class, "author")]/span[contains(@class, "name")]/text()').get()
            like_nr = div.xpath('.//span[contains(@class, "count")]/text()').get()
            url = div.xpath('.//a[contains(@class, "cover")]/@href').get()
            user_url = div.xpath('.//a[contains(@class, "author")]/@href').get()
            # 新增过滤：只要有一个字段缺失，或者点赞为“赞”，都跳过
            if not (author_name and url and user_url and is_valid_like(like_nr)):
                continue
            authorName_list.append(author_name)
            likeNr_list.append(like_nr)
            URL_list.append(url)
            userURL_list.append(user_url)
            time.sleep(0.35)
        except Exception as e:
            print(f"解析笔记时出错: {e}")
    return True

authorName_list, likeNr_list, URL_list, userURL_list = [], [], [], []
qbar = tqdm(total=num, desc="已获取的笔记数量...")
while len(URL_list) < num:
    if '- THE END -' in browser.page_source:
        print(f"当前与{key_word}有关的笔记数量少于 {num}")
        break
    parsePage(browser.page_source, authorName_list, likeNr_list, URL_list, userURL_list, num)
    qbar.update(1)
    if len(URL_list) < num:
        browser.execute_script('window.scrollTo(0,document.body.scrollHeight)')
        time.sleep(random.uniform(3, 5))
if len(URL_list) > num:
    authorName_list = authorName_list[:num]
    likeNr_list = likeNr_list[:num]
    URL_list = URL_list[:num]
    userURL_list = userURL_list[:num]
qbar.close()

# === 清洗列表数据 ===
likeNr_list = extract_large_number(likeNr_list)
URL_list = [re.sub(r'^/search_result/', '/', url) for url in URL_list if url is not None]
userURL_list = [url.split('/')[-1] for url in userURL_list if url is not None]

# === 解析笔记详情页面 ===
def parse_note_page(browser, url, commentNr_list, content_list, datePublished_list, images_list, starNr_list):
    whole_url = 'https://www.xiaohongshu.com/explore' + url
    browser.get(whole_url)
    try:
        WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@name="description"]')))
    except Exception as e:
        print(f"页面加载超时 for URL: {whole_url}, 错误: {e}")
    html = browser.page_source
    selector = Selector(text=html)
    comment_nr = selector.xpath('//*[@class="total"]/text()').extract_first(default=None)
    content = selector.xpath('//*[@name="description"]/@content').extract_first(default=None)
    datePublished = selector.xpath('//*[@class="date"]/text()').extract_first(default=None)
    images = selector.xpath('//*[@name="og:image"]/@content').extract_first(default=None)
    images = images + '.jpg' if images else None
    star_nr = selector.xpath('//*[@class="count"]/text()').extract_first(default=None)
    commentNr_list.append(comment_nr)
    content_list.append(content)
    datePublished_list.append(datePublished)
    images_list.append(images)
    starNr_list.append(star_nr)
    if comment_nr is None:
        print(f"评论数量提取失败 for URL: {whole_url}")
    if datePublished is None:
        print(f"发布时间提取失败 for URL: {whole_url}")

commentNr_list, content_list, datePublished_list, images_list, starNr_list = [], [], [], [], []
qbar = tqdm(total=len(URL_list), desc="已获取的笔记详情数量...")
for url in URL_list:
    parse_note_page(browser, url, commentNr_list, content_list, datePublished_list, images_list, starNr_list)
    qbar.update(1)
    time.sleep(random.uniform(0.5, 2))
qbar.close()

# === 清洗详情数据 ===
commentNr_list = extract_large_number(extract_number(commentNr_list))
starNr_list = extract_large_number(starNr_list)
datePublished_list = extract_date(datePublished_list)

# === 整合数据为 DataFrame ===
dic = {
    "author_name": authorName_list,
    "like_nr": likeNr_list,
    "url": URL_list,
    "user_url": userURL_list,
    "comment_nr": commentNr_list,
    "content": content_list,
    "datePublished": datePublished_list,
    "images": images_list,
    "star_nr": starNr_list,
}
df = pd.DataFrame.from_dict(dic)
df = df[~df.duplicated(keep='first')]
print(f"删除 {num - len(df)} 行重复行后剩余 {len(df)} 行。")

# === 保存到 MongoDB ===
col_name = f"{key_word}{selected_order_text}笔记Top{num}"
client = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = client["小红书关键词笔记数据"]
mycol = mydb[col_name]
mycol.insert_many(df.to_dict('records'))
print(f"数据已成功保存到 MongoDB，集合名: {col_name}")
client.close()
browser.quit()
