import json
from LAC import LAC
from collections import defaultdict, Counter
from tqdm import tqdm

# 1. 读取聚类结果
with open('merged聚类结果clean.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

lac = LAC(mode='lac')

# 2. 按主题统计高频名词
topic_texts = defaultdict(list)
for item in data:
    topic_num = item['topic_num']
    topic_texts[topic_num].append(item['内容'])

topic_blacklist = dict()
for topic_num, texts in topic_texts.items():
    words = []
    for text in tqdm(texts, desc=f"主题{topic_num}分词中"):
        lac_result = lac.run(text)
        for word, tag in zip(lac_result[0], lac_result[1]):
            if tag.startswith('n') and len(word) >= 2:
                words.append(word)
    counter = Counter(words)
    # 高频名词默认取前30个
    topic_blacklist[topic_num] = [w for w, c in counter.most_common(30)]
    print(f"主题{topic_num} 高频名词黑名单：{topic_blacklist[topic_num]}")

# 3. 保存为JSON
with open('topic_keywords_blacklist_theme.json', 'w', encoding='utf-8') as f:
    json.dump(topic_blacklist, f, ensure_ascii=False, indent=2)
print("已保存黑名单到 topic_keywords_blacklist_theme.json")
