import pandas as pd

df = pd.read_json('sky_top50.json', encoding='utf-8')
# 只保留正文里含“海关”的帖子
mask = df['content'].str.contains('海关|关员|被查关|查验|清关', na=False)
filtered_df = df[mask]

print(filtered_df[['content', 'like_nr']])
# 可直接保存/统计
filtered_df.to_json('海关_空运_扣货.json', force_ascii=False, orient='records', indent=2)
